<?php
// This file was auto-generated from sdk-root/src/data/serverlessrepo/2017-09-08/paginators-1.json
return [ 'pagination' => [ 'ListApplicationVersions' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxItems', ], 'ListApplications' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxItems', ], ],];
