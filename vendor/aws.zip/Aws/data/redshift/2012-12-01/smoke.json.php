<?php
// This file was auto-generated from sdk-root/src/data/redshift/2012-12-01/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'DescribeClusterVersions', 'input' => [], 'errorExpectedFromService' => false, ], [ 'operationName' => 'DescribeClusters', 'input' => [ 'ClusterIdentifier' => 'fake-cluster', ], 'errorExpectedFromService' => true, ], ],];
